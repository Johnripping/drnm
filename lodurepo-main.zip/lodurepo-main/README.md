<h1 align="center">
  🇮🇳 CHITIJ ᴛxᴛ ᴜᴘʟᴏᴀᴅᴇʀ 🇮🇳
</h1>

![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=Welcome+To+Txt+Uploader+Bot+!)

## 😎 Credit

🥳 Credit Goes To [Chitij](https://t.me/chitijrajput)

  
## 🔥 Commands

- **`/start`**: ⚡ check bot is alive.
- **`/chitij`**:  📁 upload txt file.
- **`/stop`**: 🛑 stop ongoing process.
- **`/restart`**: 🔮 restart the bot.
- **`/cookies`**: 🍪 upload cookies file.
- **`/e2t`**: 📝 edit txt file.
- **`/yt2txt`**: 🗃️ create txt of yt playlist (owner).
- **`/sudo add`**: 🎊 add user or group or channel (owner).
- **`/sudo remove`**: ❌ remove user or group or channel (owner).
- **`/userlist`**: 📜 list of sudo user/group/channel.
- **`/help`**: 🎉 for help.

