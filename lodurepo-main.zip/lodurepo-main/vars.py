# Don't Remove Credit Tg - @chitijrajput
# Ask Doubt on telegram @chitijrajput

from os import environ

API_ID = int(environ.get("API_ID", "28712726")) #Replace with your api id
API_HASH = environ.get("API_HASH", "06acfd441f9c3402ccdb1945e8e2a93b") #Replace with your api hash
BOT_TOKEN = environ.get("BOT_TOKEN", "7278938839:AAHB8N6pyXrGDV2eoZSsirnvRT0K45X82Dk") #Replace with your bot token
